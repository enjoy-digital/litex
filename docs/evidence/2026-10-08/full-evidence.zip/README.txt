LiteX HarmonyOS PC acceptance evidence, 2026-10-08.
Source ed0c556c32c0f52a82730dfabd40aea08a192a19.
windows/: reference run. harmonyos/: native clean online install and all native checks.
reports/: summaries and comparisons. inputs/: fixed versions and transfer hashes.
execution/: actual native runner, supplement and saved-evidence viewer (USB loopback URL passed at runtime).
No source bundles, wheel binaries or base runtime included.
Verify SHA256SUMS.txt after extraction. Documentation remains in the repository.
