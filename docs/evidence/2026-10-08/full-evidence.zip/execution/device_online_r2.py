import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
from urllib.request import Request, urlopen

url = sys.argv[1]
root = Path.home() / 'projects/litex/qa-final-20261008-online-r2'
if root.exists():
    raise SystemExit(f'Refusing to overwrite existing run: {root}')
root.mkdir()
results = root / 'results'
results.mkdir()
repo = root / 'litex'
venv = repo / '.venv-litex'
revision = 'ed0c556c32c0f52a82730dfabd40aea08a192a19'
env = os.environ.copy()
old_venv = env.pop('VIRTUAL_ENV', None)
if old_venv:
    env['PATH'] = os.pathsep.join(p for p in env['PATH'].split(os.pathsep)
                                if not p.startswith(old_venv + '/'))
for name in ('PYTHONPATH', 'PYTHONHOME', 'LITEX_VENV_DIR', 'LITEX_PIP_INDEX'):
    env.pop(name, None)
env.update(PYTHONUTF8='1', PIP_DISABLE_PIP_VERSION_CHECK='1',
           PIP_CACHE_DIR=str(root / 'pip-cache'),
           LITEX_MIGEN_URL=str(root / 'migen.bundle'), PIP_CONSTRAINT=str(root / 'constraints.txt'))
setup_exit = acceptance_exit = None
setup_error = None

def run(command, name, cwd=root, required=True, timeout=300):
    print('RUN:', ' '.join(map(str, command)), flush=True)
    with (results / name).open('w', encoding='utf-8') as log:
        completed = subprocess.run(list(map(str, command)), cwd=cwd, env=env,
                                   stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    print((results / name).read_text(encoding='utf-8', errors='replace')[-1500:], flush=True)
    print('EXIT:', completed.returncode, flush=True)
    if required and completed.returncode:
        raise RuntimeError(f'Command failed with exit {completed.returncode}: {command}')
    return completed

try:
    with urlopen(url + '/inputs.json', timeout=60) as response:
        expected = json.load(response)
    for name, digest in expected.items():
        with urlopen(url + '/' + name, timeout=120) as response:
            data = response.read()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError(f'Transfer hash mismatch: {name}')
        (root / name).write_bytes(data)
    run(['git', 'init', repo], 'source-init.log')
    run(['git', 'fetch', root / 'litex.bundle', 'refs/remotes/origin/port/harmonyos-pc'],
        'source-fetch.log', cwd=repo)
    run(['git', 'checkout', '--detach', revision], 'source-checkout.log', cwd=repo)
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, env=env).decode().strip()
    if actual != revision or venv.exists() or (root / 'migen').exists():
        raise ValueError('Fresh source / empty environment precondition failed')
    provenance = {'litex_commit': actual, 'migen_expected_commit': '4c2ae8dfeea37f235b52acb8166f12acaaae4f7c',
                  'bootstrap_python': sys.executable, 'bootstrap_version': sys.version,
                  'venv_absent_before_setup': True, 'migen_absent_before_setup': True,
                  'installer_unmodified': True, 'installer': 'sh scripts/setup_harmonyos.sh',
                  'source_transport': 'SHA256-checked Git bundles through USB loopback',
                  'dependency_transport': 'installer default pip index; dedicated empty pip cache; fixed PIP_CONSTRAINT',
                  'transfer_sha256': expected, 'PYTHONUTF8': '1'}
    (results / 'provenance.json').write_text(json.dumps(provenance, indent=2), encoding='utf-8')
    setup_exit = run(['sh', 'scripts/setup_harmonyos.sh'], 'installer.log', cwd=repo,
                     required=False, timeout=900).returncode
    for path in (repo / 'logs').glob('*.json'):
        (results / path.name).write_bytes(path.read_bytes())
    if setup_exit != 0:
        raise RuntimeError(f'Unmodified PR1 installer failed: {setup_exit}')
    python = venv / 'bin/python'
    (results / 'pyvenv.cfg').write_bytes((venv / 'pyvenv.cfg').read_bytes())
    run([python, '-m', 'pip', 'freeze', '--all'], 'requirements.txt', cwd=repo)
    run(['git', 'rev-parse', 'HEAD'], 'migen-commit.txt', cwd=root / 'migen')
    run([python, '-c', 'import sys, json, migen, litex; print(json.dumps(dict(executable=sys.executable, prefix=sys.prefix, base_prefix=sys.base_prefix, path=sys.path, migen=migen.__file__, litex=litex.__file__), indent=2))'],
        'environment-isolation.json', cwd=repo)
    run([python, 'scripts/check_environment.py', '--json', results / 'post-install-check.json'],
        'post-install-check.log', cwd=repo, required=False)
    acceptance_exit = run([python, 'scripts/run_acceptance.py', '--output-dir', results / 'acceptance'],
                          'acceptance-console.log', cwd=repo, required=False).returncode
    run(['git', 'status', '--short'], 'source-status.txt', cwd=repo)
    run(['git', 'diff', '--name-only', 'HEAD'], 'source-tracked-diff.txt', cwd=repo)
except Exception:
    setup_error = traceback.format_exc()
    (results / 'setup-error.log').write_text(setup_error, encoding='utf-8')
    print(setup_error, flush=True)
finally:
    payload = {'setup_error': setup_error, 'setup_exit': setup_exit, 'acceptance_exit': acceptance_exit,
               'files': {path.relative_to(results).as_posix(): base64.b64encode(path.read_bytes()).decode('ascii')
                         for path in sorted(results.rglob('*')) if path.is_file()}}
    encoded = json.dumps(payload).encode('utf-8')
    (root / 'harmony-result.json').write_bytes(encoded)
    request = Request(url + '/harmony-result.json', data=encoded, method='POST',
                      headers={'Content-Type': 'application/json'})
    with urlopen(request, timeout=60) as response:
        print('RESULT_UPLOADED:', response.read().decode(), flush=True)
print('LITEX_CLEAN_SETUP_EXIT:', setup_exit, 'ACCEPTANCE_EXIT:', acceptance_exit, flush=True)
