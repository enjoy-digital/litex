import json,sys,subprocess,base64
from urllib.request import Request,urlopen
from pathlib import Path
root=Path.home()/'projects/litex/qa-final-20261008-online-r2'
r=root/'results'
a=json.loads((r/'acceptance/acceptance-report.json').read_text())
print('\033[2J\033[H',end='')
print('LiteX / HarmonyOS PC - 2026-10-08')
print('SAVED EVIDENCE DISPLAY - no test rerun')
print()
if sys.argv[-1]=='environment':
    repo=root/'litex'
    checks={name:subprocess.check_output(command,cwd=repo).decode() for name,command in {
        'tracked_diff':['git','diff','--name-only','HEAD'],
        'status':['git','status','--short'],
        'head':['git','rev-parse','HEAD'],
    }.items()}
    data=json.dumps(checks,indent=2).encode()
    (r/'source-integrity.json').write_bytes(data)
    payload=json.loads((root/'harmony-result.json').read_text())
    payload['files']['source-integrity.json']=base64.b64encode(data).decode()
    with urlopen(Request(sys.argv[1]+'/harmony-result.json',data=json.dumps(payload).encode(),method='POST',headers={'Content-Type':'application/json'}),timeout=60) as response: response.read()
    print('Tracked source diff: '+('EMPTY' if not checks['tracked_diff'] else checks['tracked_diff']))
    for k in ('platform','machine','python','git_commit'):
        print(k+': '+str(a['environment'][k]))
    print('Migen: '+(r/'migen-commit.txt').read_text().strip())
    print('Fresh source / venv / cache; unmodified installer')
    print('Install transport: SHA256-checked Git bundles + online PyPI dependencies')
    print((r/'pyvenv.cfg').read_text().split('include-system-site-packages')[1].splitlines()[0].join(['include-system-site-packages','']))
else:
    s=json.loads((r/'supplement.json').read_text())
    print('Source: '+a['environment']['git_commit'])
    print('Required acceptance: '+a['status']+' '+str(a['required_passed'])+'/'+str(a['required_total']))
    for f in ('acceptance/logs/portable-core-tests.log','focused-regression.log'):
        for line in (r/f).read_text().splitlines():
            if line.startswith('Ran ') or line=='OK': print(f.split('/')[-1]+': '+line)
    print('CLI help exits: '+str(s['cli']))
    print('Repeat/unicode/space: '+json.loads((r/'repeat-comparison.json').read_text())['status'])
    print('Invalid clock: '+str(s['invalid_clock']))
    print('Clean safety: '+str(s['clean_safety']))
    print('Extension: litex_sim help failed, missing LiteEth')
    print('No BIOS / Verilator / physical FPGA claim')
