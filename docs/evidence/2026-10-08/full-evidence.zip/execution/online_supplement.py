import base64,json,os,subprocess,sys,traceback
from pathlib import Path
from urllib.request import Request,urlopen
url=sys.argv[1]
root=Path.home()/'projects/litex/qa-final-20261008-online-r2'
results=root/'results'
repo=root/'litex'
venv=repo/'.venv-litex'
python=venv/'bin/python'
env=os.environ.copy(); env['PYTHONUTF8']='1'
def run(command,name,cwd=root,required=True,timeout=300):
    with (results/name).open('w',encoding='utf-8') as log:
        p=subprocess.run(list(map(str,command)),cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    print(name,p.returncode,flush=True)
    if required and p.returncode: raise RuntimeError(name)
    return p
try:
    focused = run([python, '-m', 'unittest', '-v',
        'test.interconnect.test_stream.TestStream.test_byte_count',
        'test.interconnect.test_stream.TestStream.test_byte_mask',
        'test.build.test_pmod.TestPmod',
        'test.build.test_generic_platform_toolchain.TestGenericToolchain.test_build_litex_backend_generates_verilog_project_and_script'],
        'focused-regression.log', cwd=repo, required=False).returncode
    cli = {}
    for tool in ('litex_soc_gen', 'litex_periph_gen', 'litex_term'):
        cli[tool] = run([venv / 'bin' / tool, '--help'], tool + '-help.log', cwd=repo, required=False).returncode
    sample = repo / 'examples/minimal_soc_baseline.py'
    repeat = results / '重复生成 空格'
    repeat_exit = run([python, sample, '--output-dir', repeat], 'repeat-generation.log', cwd=repo, required=False).returncode
    compare_exit = run([python, repo / 'scripts/compare_baseline.py', results / 'acceptance/minimal-soc', repeat,
        '--output', results / 'repeat-comparison.json'], 'repeat-comparison.log', cwd=repo, required=False).returncode
    invalid = []
    for index, value in enumerate(('0', '-1', 'nonnumeric')):
        target = root / ('invalid-output-' + str(index))
        code = run([python, sample, '--output-dir', target, '--sys-clk-freq', value],
            'invalid-clock-' + str(index) + '.log', cwd=repo, required=False).returncode
        invalid.append(dict(value=value, exit_code=code, output_absent=not target.exists()))
    safe = root / 'clean-safety'
    safe.mkdir()
    sentinel = safe / 'keep.txt'
    sentinel.write_text('preserve this sentinel', encoding='utf-8')
    code = run([python, sample, '--output-dir', '.', '--clean'], 'clean-safety.log', cwd=safe, required=False).returncode
    safety = dict(exit_code=code, sentinel_preserved=sentinel.read_text() == 'preserve this sentinel')
    supplement = dict(focused_exit=focused, cli=cli, repeat_exit=repeat_exit, repeat_compare_exit=compare_exit,
                      invalid_clock=invalid, clean_safety=safety)
    (results / 'supplement.json').write_text(json.dumps(supplement, indent=2), encoding='utf-8')
    run([python,'-c','import sys, json; from serial.tools import list_ports; print(json.dumps(dict(sys_platform=sys.platform, ports=[p.device for p in list_ports.comports()]), indent=2))'],'serial-enumeration.json',cwd=repo,required=False)
except Exception:
    (results/'supplement-error.log').write_text(traceback.format_exc(),encoding='utf-8')
    raise
finally:
    payload={'setup_error':None,'setup_exit':0,'acceptance_exit':0,'files':{p.relative_to(results).as_posix():base64.b64encode(p.read_bytes()).decode() for p in results.rglob('*') if p.is_file()}}
    encoded=json.dumps(payload).encode()
    (root/'harmony-result.json').write_bytes(encoded)
    with urlopen(Request(url+'/harmony-result.json',data=encoded,method='POST',headers={'Content-Type':'application/json'}),timeout=60) as r: print('RESULT_UPLOADED',r.read().decode())
